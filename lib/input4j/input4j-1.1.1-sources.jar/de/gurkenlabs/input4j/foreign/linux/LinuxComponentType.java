package de.gurkenlabs.input4j.foreign.linux;

import de.gurkenlabs.input4j.ComponentType;

import java.util.Arrays;

/**
 * Linux input event component types mapping to Linux input event codes.
 */
public enum LinuxComponentType {
  UNKNOWN(-1),
  KEY_ESC(1),
  KEY_1(2),
  KEY_2(3),
  KEY_3(4),
  KEY_4(5),
  KEY_5(6),
  KEY_6(7),
  KEY_7(8),
  KEY_8(9),
  KEY_9(10),
  KEY_0(11),
  KEY_MINUS(12),
  KEY_EQUAL(13),
  KEY_BACKSPACE(14),
  KEY_TAB(15),
  KEY_Q(16),
  KEY_W(17),
  KEY_E(18),
  KEY_R(19),
  KEY_T(20),
  KEY_Y(21),
  KEY_U(22),
  KEY_I(23),
  KEY_O(24),
  KEY_P(25),
  KEY_LEFTBRACE(26),
  KEY_RIGHTBRACE(27),
  KEY_ENTER(28),
  KEY_LEFTCTRL(29),
  KEY_A(30),
  KEY_S(31),
  KEY_D(32),
  KEY_F(33),
  KEY_G(34),
  KEY_H(35),
  KEY_J(36),
  KEY_K(37),
  KEY_L(38),
  KEY_SEMICOLON(39),
  KEY_APOSTROPHE(40),
  KEY_GRAVE(41),
  KEY_LEFTSHIFT(42),
  KEY_BACKSLASH(43),
  KEY_Z(44),
  KEY_X(45),
  KEY_C(46),
  KEY_V(47),
  KEY_B(48),
  KEY_N(49),
  KEY_M(50),
  KEY_COMMA(51),
  KEY_DOT(52),
  KEY_SLASH(53),
  KEY_RIGHTSHIFT(54),
  KEY_KPASTERISK(55),
  KEY_LEFTALT(56),
  KEY_SPACE(57),
  KEY_CAPSLOCK(58),
  KEY_F1(59),
  KEY_F2(60),
  KEY_F3(61),
  KEY_F4(62),
  KEY_F5(63),
  KEY_F6(64),
  KEY_F7(65),
  KEY_F8(66),
  KEY_F9(67),
  KEY_F10(68),
  KEY_NUMLOCK(69),
  KEY_SCROLLLOCK(70),
  KEY_KP7(71),
  KEY_KP8(72),
  KEY_KP9(73),
  KEY_KPMINUS(74),
  KEY_KP4(75),
  KEY_KP5(76),
  KEY_KP6(77),
  KEY_KPPLUS(78),
  KEY_KP1(79),
  KEY_KP2(80),
  KEY_KP3(81),
  KEY_KP0(82),
  KEY_KPDOT(83),
  KEY_ZENKAKUHANKAKU(85),
  KEY_102ND(86),
  KEY_F11(87),
  KEY_F12(88),
  KEY_RO(89),
  KEY_KATAKANA(90),
  KEY_HIRAGANA(91),
  KEY_HENKAN(92),
  KEY_KATAKANAHIRAGANA(93),
  KEY_MUHENKAN(94),
  KEY_KPJPCOMMA(95),
  KEY_KPENTER(96),
  KEY_RIGHTCTRL(97),
  KEY_KPSLASH(98),
  KEY_SYSRQ(99),
  KEY_RIGHTALT(100),
  KEY_LINEFEED(101),
  KEY_HOME(102),
  KEY_UP(103),
  KEY_PAGEUP(104),
  KEY_LEFT(105),
  KEY_RIGHT(106),
  KEY_END(107),
  KEY_DOWN(108),
  KEY_PAGEDOWN(109),
  KEY_INSERT(110),
  KEY_DELETE(111),
  KEY_MACRO(112),
  KEY_MUTE(113),
  KEY_VOLUMEDOWN(114),
  KEY_VOLUMEUP(115),
  KEY_POWER(116),
  KEY_KPEQUAL(117),
  KEY_KPPLUSMINUS(118),
  KEY_PAUSE(119),
  KEY_SCALE(120),
  KEY_KPCOMMA(121),
  KEY_HANGEUL(122),
  KEY_HANJA(123),
  KEY_YEN(124),
  KEY_LEFTMETA(125),
  KEY_RIGHTMETA(126),
  KEY_COMPOSE(127),
  KEY_STOP(128),
  KEY_AGAIN(129),
  KEY_PROPS(130),
  KEY_UNDO(131),
  KEY_FRONT(132),
  KEY_COPY(133),
  KEY_OPEN(134),
  KEY_PASTE(135),
  KEY_FIND(136),
  KEY_CUT(137),
  KEY_HELP(138),
  KEY_MENU(139),
  KEY_CALC(140),
  KEY_SETUP(141),
  KEY_SLEEP(142),
  KEY_WAKEUP(143),
  KEY_FILE(144),
  KEY_SENDFILE(145),
  KEY_DELETEFILE(146),
  KEY_XFER(147),
  KEY_PROG1(148),
  KEY_PROG2(149),
  KEY_WWW(150),
  KEY_MSDOS(151),
  KEY_SCREENLOCK(152),
  KEY_DIRECTION(153),
  KEY_CYCLEWINDOWS(154),
  KEY_MAIL(155),
  KEY_BOOKMARKS(156),
  KEY_COMPUTER(157),
  KEY_BACK(158),
  KEY_FORWARD(159),
  KEY_CLOSECD(160),
  KEY_EJECTCD(161),
  KEY_EJECTCLOSECD(162),
  KEY_NEXTSONG(163),
  KEY_PLAYPAUSE(164),
  KEY_PREVIOUSSONG(165),
  KEY_STOPCD(166),
  KEY_RECORD(167),
  KEY_REWIND(168),
  KEY_PHONE(169),
  KEY_ISO(170),
  KEY_CONFIG(171),
  KEY_HOMEPAGE(172),
  KEY_REFRESH(173),
  KEY_EXIT(174),
  KEY_MOVE(175),
  KEY_EDIT(176),
  KEY_SCROLLUP(177),
  KEY_SCROLLDOWN(178),
  KEY_KPLEFTPAREN(179),
  KEY_KPRIGHTPAREN(180),
  KEY_NEW(181),
  KEY_REDO(182),
  KEY_F13(183),
  KEY_F14(184),
  KEY_F15(185),
  KEY_F16(186),
  KEY_F17(187),
  KEY_F18(188),
  KEY_F19(189),
  KEY_F20(190),
  KEY_F21(191),
  KEY_F22(192),
  KEY_F23(193),
  KEY_F24(194),
  KEY_PLAYCD(200),
  KEY_PAUSECD(201),
  KEY_PROG3(202),
  KEY_PROG4(203),
  KEY_DASHBOARD(204),
  KEY_SUSPEND(205),
  KEY_CLOSE(206),
  KEY_PLAY(207),
  KEY_FASTFORWARD(208),
  KEY_BASSBOOST(209),
  KEY_PRINT(210),
  KEY_HP(211),
  KEY_CAMERA(212),
  KEY_SOUND(213),
  KEY_QUESTION(214),
  KEY_EMAIL(215),
  KEY_CHAT(216),
  KEY_SEARCH(217),
  KEY_CONNECT(218),
  KEY_FINANCE(219),
  KEY_SPORT(220),
  KEY_SHOP(221),
  KEY_ALTERASE(222),
  KEY_CANCEL(223),
  KEY_BRIGHTNESSDOWN(224),
  KEY_BRIGHTNESSUP(225),
  KEY_MEDIA(226),
  KEY_SWITCHVIDEOMODE(227),
  KEY_KBDILLUMTOGGLE(228),
  KEY_KBDILLUMDOWN(229),
  KEY_KBDILLUMUP(230),
  KEY_SEND(231),
  KEY_REPLY(232),
  KEY_FORWARDMAIL(233),
  KEY_SAVE(234),
  KEY_DOCUMENTS(235),
  KEY_BATTERY(236),
  KEY_BLUETOOTH(237),
  KEY_WLAN(238),
  KEY_UWB(239),
  KEY_UNKNOWN(240),
  KEY_VIDEO_NEXT(241),
  KEY_VIDEO_PREV(242),
  KEY_BRIGHTNESS_CYCLE(243),
  KEY_BRIGHTNESS_ZERO(244),
  KEY_DISPLAY_OFF(245),
  KEY_WIMAX(246),
  KEY_RFKILL(247),
  KEY_MICMUTE(248),
  BTN_0(0x100),
  BTN_1(0x101),
  BTN_2(0x102),
  BTN_3(0x103),
  BTN_4(0x104),
  BTN_5(0x105),
  BTN_6(0x106),
  BTN_7(0x107),
  BTN_8(0x108),
  BTN_9(0x109),
  BTN_LEFT(0x110),
  BTN_RIGHT(0x111),
  BTN_MIDDLE(0x112),
  BTN_SIDE(0x113),
  BTN_EXTRA(0x114),
  BTN_FORWARD(0x115),
  BTN_BACK(0x116),
  BTN_TRIGGER(0x120),
  BTN_THUMB(0x121),
  BTN_THUMB2(0x122),
  BTN_TOP(0x123),
  BTN_TOP2(0x124),
  BTN_PINKIE(0x125),
  BTN_BASE(0x126),
  BTN_BASE2(0x127),
  BTN_BASE3(0x128),
  BTN_BASE4(0x129),
  BTN_BASE5(0x12A),
  BTN_BASE6(0x12B),
  BTN_DEAD(0x12F),
  BTN_SOUTH(0x130),
  BTN_EAST(0x131),
  BTN_C(0x132),
  BTN_NORTH(0x133),
  BTN_WEST(0x134),
  BTN_Z(0x135),
  BTN_TL(0x136),
  BTN_TR(0x137),
  BTN_TL2(0x138),
  BTN_TR2(0x139),
  BTN_SELECT(0x13A),
  BTN_START(0x13B),
  BTN_MODE(0x13C),
  BTN_THUMBL(0x13D),
  BTN_THUMBR(0x13E),
  BTN_TRIGGER_HAPPY(0x2c0),
  BTN_TRIGGER_HAPPY1(0x2c0),
  BTN_TRIGGER_HAPPY2(0x2c1),
  BTN_TRIGGER_HAPPY3(0x2c2),
  BTN_TRIGGER_HAPPY4(0x2c3),
  BTN_TRIGGER_HAPPY5(0x2c4),
  BTN_TRIGGER_HAPPY6(0x2c5),
  BTN_TRIGGER_HAPPY7(0x2c6),
  BTN_TRIGGER_HAPPY8(0x2c7),
  BTN_TRIGGER_HAPPY9(0x2c8),
  BTN_TRIGGER_HAPPY10(0x2c9),
  BTN_TRIGGER_HAPPY11(0x2ca),
  BTN_TRIGGER_HAPPY12(0x2cb),
  BTN_TRIGGER_HAPPY13(0x2cc),
  BTN_TRIGGER_HAPPY14(0x2cd),
  BTN_TRIGGER_HAPPY15(0x2ce),
  BTN_TRIGGER_HAPPY16(0x2cf),
  BTN_TRIGGER_HAPPY17(0x2d0),
  BTN_TRIGGER_HAPPY18(0x2d1),
  BTN_TRIGGER_HAPPY19(0x2d2),
  BTN_TRIGGER_HAPPY20(0x2d3),
  BTN_TRIGGER_HAPPY21(0x2d4),
  BTN_TRIGGER_HAPPY22(0x2d5),
  BTN_TRIGGER_HAPPY23(0x2d6),
  BTN_TRIGGER_HAPPY24(0x2d7),
  BTN_TRIGGER_HAPPY25(0x2d8),
  BTN_TRIGGER_HAPPY26(0x2d9),
  BTN_TRIGGER_HAPPY27(0x2da),
  BTN_TRIGGER_HAPPY28(0x2db),
  BTN_TRIGGER_HAPPY29(0x2dc),
  BTN_TRIGGER_HAPPY30(0x2dd),
  BTN_TRIGGER_HAPPY31(0x2de),
  BTN_TRIGGER_HAPPY32(0x2df),
  BTN_TRIGGER_HAPPY33(0x2e0),
  BTN_TRIGGER_HAPPY34(0x2e1),
  BTN_TRIGGER_HAPPY35(0x2e2),
  BTN_TRIGGER_HAPPY36(0x2e3),
  BTN_TRIGGER_HAPPY37(0x2e4),
  BTN_TRIGGER_HAPPY38(0x2e5),
  BTN_TRIGGER_HAPPY39(0x2e6),
  BTN_TRIGGER_HAPPY40(0x2e7),
  ABS_X(0x00, true),
  ABS_Y(0x01, true),
  ABS_Z(0x02, true),
  ABS_RX(0x03, true),
  ABS_RY(0x04, true),
  ABS_RZ(0x05, true),
  ABS_THROTTLE(0x06, true),
  ABS_RUDDER(0x07, true),
  ABS_WHEEL(0x08, true),
  ABS_GAS(0x09, true),
  ABS_BRAKE(0x0A, true),
  ABS_HAT0X(0x10, true),
  ABS_HAT0Y(0x11, true),
  ABS_HAT1X(0x12, true),
  ABS_HAT1Y(0x13, true),
  ABS_HAT2X(0x14, true),
  ABS_HAT2Y(0x15, true),
  ABS_HAT3X(0x16, true),
  ABS_HAT3Y(0x17, true),
  REL_X(0x00, true, true),
  REL_Y(0x01, true, true),
  REL_Z(0x02, true, true),
  REL_WHEEL(0x08, true, true),
  REL_HWHEEL(0x06, true, true),
  REL_DIAL(0x07, true, true),
  REL_MISC(0x09, true, true);

  /**
   * Cache the values array to avoid creating a new array each time values() is called.
   */
  private static final LinuxComponentType[] values = values();

  private final int code;
  private final boolean axis;
  private final boolean relative;

  LinuxComponentType(int code) {
    this(code, false);
  }

  LinuxComponentType(int code, boolean axis) {
    this(code, axis, false);
  }

  LinuxComponentType(int code, boolean axis, boolean relative) {
    this.code = code;
    this.axis = axis;
    this.relative = relative;
  }

  /**
   * Gets the Linux input event code.
   *
   * @return the event code
   */
  public int getCode() {
    return code;
  }

  /**
   * Gets a LinuxComponentType from a native code.
   *
   * @param nativeCode the native Linux input event code
   * @param axis       true if it's an axis
   * @param relative   true if it's a relative axis
   * @return the LinuxComponentType or UNKNOWN
   */
  public static LinuxComponentType fromCode(int nativeCode, boolean axis, boolean relative) {
    return Arrays.stream(LinuxComponentType.values)
            .filter(type -> type.code == nativeCode && (type.axis == axis && (!relative || type.relative)))
            .findFirst()
            .orElse(UNKNOWN);
  }

  /**
   * Gets the ComponentType for a native code.
   *
   * @param nativeCode the native Linux input event code
   * @param axis       true if it's an axis
   * @param relative   true if it's a relative axis
   * @return the ComponentType
   */
  public ComponentType getComponentType(int nativeCode, boolean axis, boolean relative) {
    var type = fromCode(nativeCode, axis, relative);
    if (type == UNKNOWN) {
      return ComponentType.UNKNOWN;
    }

    if (type.name().startsWith("KEY")) {
      return ComponentType.KEY;
    }else if (type.name().startsWith("BTN")) {
      return ComponentType.BUTTON;
    } else if (type.name().startsWith("ABS_HAT")) {
      return ComponentType.AXIS;
    }

    return switch (type) {
      case ABS_X, ABS_RX, ABS_Y, ABS_Z, ABS_RY, ABS_RZ -> ComponentType.AXIS;
      default -> ComponentType.UNKNOWN;
    };
  }

  /**
   * Checks if this component type is an axis (ABS or REL).
   *
   * @return true if it's an axis
   */
  public boolean isAxis() {
    return this.name().startsWith("ABS") || this.name().startsWith("REL");
  }
}
